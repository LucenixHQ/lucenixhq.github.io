Starting LucenixHQ research
